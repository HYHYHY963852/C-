# GreedySnake
c++经典项目贪吃蛇游戏控制台版，详细注释。
(点个star再走不急)
教程地址：http://blog.csdn.net/silence1772/article/details/55005008

## 游戏截图：
![](https://github.com/silence1772/GreedySnake/raw/master/shot01.jpg)
![](https://github.com/silence1772/GreedySnake/raw/master/shot02.jpg)
![](https://github.com/silence1772/GreedySnake/raw/master/shot03.gif)
![](https://github.com/silence1772/GreedySnake/raw/master/shot04.gif)
